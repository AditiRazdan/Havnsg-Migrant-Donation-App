<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
class Request extends CI_Controller {  
	public function __construct(){ 
		parent::__construct();
		$this->load->database();
		//$this->oakter = $this->load->database('oakter',TRUE);
		$this->load->library(array('form_validation')); 
		$this->load->helper(array('url','html','form'));
	}
	
	public function token($data)
    {
        $jwt = new JWT();
        $jwtSecretKey = "Superman@77";
        $token = $jwt->encode($data, $jwtSecretKey, 'HS256');
        return $token;
    }
    
    public function get_token($dataToken){
        $jwt = new JWT();
        $jwtSecretKey = "Superman@77";
        $token = $jwt->decode($dataToken,$jwtSecretKey,true);
        return $token;
    }
	public function success_response($msg, $data)
    {
        $response = array(
          "success" => true,
          "msg" => $msg,
          "data" => $data
        );
        return $response;
    }
    
    public function failure_response($msg, $error)
    {
        $response = array(
          "success" => false,
          "msg" => $msg,
          "error" => $error
        );
        return $response;
    }
    
    
    public function addCategory()
    {
        $Authorization = $this->input->get_request_header("Authorization");
       if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           $this->form_validation->set_rules('name', 'Name', 'required');
           if(empty($_FILES["categoryImage"]['name']))
            { 
                $this->form_validation->set_rules('categoryImage', 'Category Image', 'required');
            }
            
            if ($this->form_validation->run() == FALSE) {
              print_r($this->form_validation->error_array());
            }else{
                if(!empty($_FILES["categoryImage"]['name']))
                { 
                    $fileName = $this->upload_doc_single('uploads/category', $_FILES["categoryImage"], 'image');
                }else{
                    $fileName = "";
                }
                
                $date = date('Y-m-d H:i:s', time());
                $params = array(
                    "name" => $_POST['name'],
                    "categoryImage" => $fileName,
    				'cretedAt' => $date,
    				'createdBy' => $accesToken->id,
    				'modifiedAt' => $date,
    				'modifiedBy' => $accesToken->id,
                );
                $this->db->insert('categories',$params); 
                $categoryId = $this->db->insert_id();
                $category = $this->db->select('*')->where('id', $categoryId)->get('categories')->row_array();
                $msg = "Category Created";
                $response = $this->success_response($msg, $category);
            //   echo "<pre>";
            //   print_r($params);
            //   die;
                   
            }
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, $msg);
       }
        echo json_encode($response); 
    }
    
    public function getCategory()
    {
        $result = $this->db->select('*')->where('parentCategory', null)->get('categories')->result_array();
        
        if(isset($result) && !empty($result)){
            $res = array();
            $i = 0;
            foreach($result as $r){
                $r['v'] = 1;
                $r['image'] = $r['categoryImage'];
                $r['isActive'] = true;
                unset($r['parentCategory'], $r['categoryImage']);
                $res[$i] = $r;
                $i++;
            }
            
            $msg = "Success";
            $response = $this->success_response($msg, $res);
        } else {
            $msg = "Category Not Found";
            $response = $this->failure_response($msg, $result);
        }
        header('Content-Type: application/json');
        echo json_encode($response);
    }
    public function getSingleCategory($num)
    {
        $result = $this->db->select('*')->where('id', $num)->get('categories')->row_array();
        
        if(isset($result) && !empty($result)){
            $msg = "Success";
            $response = $this->success_response($msg, $result);
        } else {
            $msg = "Category Not Found";
            $response = $this->failure_response($msg, $msg);
        }
        echo json_encode($response);
    }
    public function updateCatergory($id)
    {
        $category = $this->db->select('*')->where('id', $id)->get('categories')->row_array();
       $Authorization = $this->input->get_request_header("Authorization");
       if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           $this->form_validation->set_rules('name', 'Name', 'required');
            if ($this->form_validation->run() == FALSE) {
              print_r($this->form_validation->error_array());
            }else{
                if(!empty($_FILES["categoryImage"]['name']))
                { 
                    $fileName = $this->upload_doc_single('uploads/category', $_FILES["categoryImage"], 'image');
                }else{
                    $fileName = $category['categoryImage'];
                }
                
                $date = date('Y-m-d H:i:s', time());
                $params = array(
                    "name" => $_POST['name'],
                    "categoryImage" => $fileName,
    				'cretedAt' => $date,
    				'createdBy' => $accesToken->id,
    				'modifiedAt' => $date,
    				'modifiedBy' => $accesToken->id,
                );
                $this->db->where('id', $id);
                $this->db->update('categories', $params);
                $msg = "Category Updated";
                $response = $this->success_response($msg, '');
                   
            }
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, $msg);
       }
        echo json_encode($response); 
    }
    
    // Subcategory  
    
    public function addSubcategory()
    {
       $Authorization = $this->input->get_request_header("Authorization");
       if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           $this->form_validation->set_rules('name', 'Name', 'required');
           $this->form_validation->set_rules('parentCategory', 'Category', 'required');
           if(empty($_FILES["categoryImage"]['name']))
            { 
                $this->form_validation->set_rules('categoryImage', 'Category Image', 'required');
            }
            
            if ($this->form_validation->run() == FALSE) {
              print_r($this->form_validation->error_array());
            }else{
                if(!empty($_FILES["categoryImage"]['name']))
                { 
                    $fileName = $this->upload_doc_single('uploads/category', $_FILES["categoryImage"], 'image');
                }else{
                    $fileName = "";
                }
                
                $date = date('Y-m-d H:i:s', time());
                $params = array(
                    "name" => $_POST['name'],
                    "parentCategory" => $_POST['parentCategory'],
                    "categoryImage" => $fileName,
    				'cretedAt' => $date,
    				'createdBy' => $accesToken->id,
    				'modifiedAt' => $date,
    				'modifiedBy' => $accesToken->id,
                );
                $this->db->insert('categories',$params); 
                $categoryId = $this->db->insert_id();
                $category = $this->db->select('*')->where('id', $categoryId)->get('categories')->row_array();
                $msg = "Sub Category Created";
                $response = $this->success_response($msg, $category);
          
                   
            }
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, $msg);
       }
        echo json_encode($response);  
    }
    
        
    public function getSubCategory($categoryId)
    {
        
        $result = $this->db->select('*')->where('parentCategory', $categoryId)->get('categories')->result_array();
        
        if(isset($result) && !empty($result)){
            $msg = "Success";
            $response = $this->success_response($msg, $result);
        } else {
            $msg = "Category Not Found";
            $response = $this->failure_response($msg, $result);
        }
        echo json_encode($response);
    }
    
    
    public function getSingleCategory($id)
    {
        $result = $this->db->select('*')->where('id', $id)->get('categories')->row_array();
        
        if(isset($result) && !empty($result)){
            $msg = "Success";
            $response = $this->success_response($msg, $result);
        } else {
            $msg = "Category Not Found";
            $response = $this->failure_response($msg, $msg);
        }
        echo json_encode($response);
    }
    
    public function updateSubcategory($id)
    {
        $category = $this->db->select('*')->where('id', $id)->get('categories')->row_array();
        // echo "<pre>";
        // print_r($category);
        // die;
       $Authorization = $this->input->get_request_header("Authorization");
       if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           $this->form_validation->set_rules('name', 'Name', 'required');
           $this->form_validation->set_rules('parentCategory', 'Category', 'required');
            if ($this->form_validation->run() == FALSE) {
              print_r($this->form_validation->error_array());
            }else{
                if(!empty($_FILES["categoryImage"]['name']))
                { 
                    $fileName = $this->upload_doc_single('uploads/category', $_FILES["categoryImage"], 'image');
                }else{
                    $fileName = $category['categoryImage'];
                }
                
                $date = date('Y-m-d H:i:s', time());
                $params = array(
                    "name" => $_POST['name'],
                    "categoryImage" => $fileName,
                    "parentCategory" => $_POST['parentCategory'],
    				'cretedAt' => $date,
    				'createdBy' => $accesToken->id,
    				'modifiedAt' => $date,
    				'modifiedBy' => $accesToken->id,
                );
                $this->db->where('id', $id);
                $this->db->update('categories', $params);
                $msg = "Category Updated";
                $response = $this->success_response($msg, '');
            //   echo "<pre>";
            //   print_r($params);
            //   die;
                   
            }
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, $msg);
       }
        echo json_encode($response);
    }

    
}