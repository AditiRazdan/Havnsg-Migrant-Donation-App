<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/RestController.php';
require APPPATH . '/libraries/Format.php';

use chriskacerguis\RestServer\RestController;

class Register extends RestController
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        // $this->load->model('StudentModel');
    }
    
    public function token($data)
    {
        $jwt = new JWT();
        $jwtSecretKey = "Superman@77";
        $token = $jwt->encode($data, $jwtSecretKey, 'HS256');
        return $token;
    }
    
    public function success_response($msg, $data)
    {
        $response = array(
          "success" => true,
          "msg" => $msg,
          "data" => $data
        );
        return $response;
    }
    
    public function failure_response($msg, $error)
    {
        $response = array(
          "success" => false,
          "msg" => $msg,
          "error" => $error
        );
        return $response;
    }
    public function index_post()
    {
        $_POST = json_decode(file_get_contents("php://input"), true);
       $this->form_validation->set_rules('firstName', 'First Name', 'required');
       $this->form_validation->set_rules('lastName', 'Last Name', 'required');
       $this->form_validation->set_rules('email', 'Email', 'required|is_unique[user.email');
       $this->form_validation->set_rules('mobile', 'Mobile', 'required|numeric|is_unique[user.mobile');
       $this->form_validation->set_rules('password', 'password', 'required');
       $this->form_validation->set_rules('userType', 'UserType', 'required');
       $this->form_validation->set_rules('region', 'Region', 'required');
       $this->form_validation->set_rules('address', 'Address', 'required');
       $this->form_validation->set_rules('deviceType', 'Device Type', 'required');
       $this->form_validation->set_rules('deviceToken', 'Device Token', 'required');


        if ($this->form_validation->run() == FALSE) {
          print_r($this->form_validation->error_array());
        }else{
            if($_POST['password'] == $_POST['confirmPassword']){
                $params = array(
                    "firstName" => $_POST['firstName'],
                    "lastName" => $_POST['lastName'],
                    "email" => $_POST['email'],
                    "mobile" => $_POST['mobile'],
                    "password" => $_POST['password'],
                    "userType" => $_POST['userType'],
                    "region" => $_POST['region'],
                    "address" => $_POST['address'],
                    "deviceType" => $_POST['deviceType'],
                    "deviceToken" => $_POST['deviceToken']
                    );
                echo "<pre>";
                print_r($params);
                die;
            }else{
               $msg = "Password confirmation does not match password";
                $response = $this->failure_response($msg, 'ERROR'); 
            }
               
        }
        
    }



    public function editStudent_get($id)
    {
        $students = new StudentModel;
        $students = $students->edit_student($id);
        $this->response($students, 200);
    }

    public function updateStudent_put($id)
    {
        $students = new StudentModel;
        $data = [
            'name' =>  $this->put('name'),
            'class' => $this->put('class'),
            'email' => $this->put('email')
        ];
        $result = $students->update_student($id, $data);
        if($result > 0)
        {
            $this->response([
                'status' => true,
                'message' => 'STUDENT UPDATED'
            ], RestController::HTTP_OK); 
        }
        else
        {
            $this->response([
                'status' => false,
                'message' => 'FAILED TO UPDATE STUDENT'
            ], RestController::HTTP_BAD_REQUEST);
        }
    }

}

?>