<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/RestController.php';
require APPPATH . '/libraries/Format.php';

use chriskacerguis\RestServer\RestController;

class Item extends RestController
{

    public function __construct()
    {
        parent::__construct();
        // $this->load->model('StudentModel');
    }
    
    public function token($data)
    {
        $jwt = new JWT();
        $jwtSecretKey = "Superman@77";
        $token = $jwt->encode($data, $jwtSecretKey, 'HS256');
        return $token;
    }
    
    public function success_response($msg, $data)
    {
        $response = array(
          "success" => true,
          "msg" => $msg,
          "data" => $data
        );
        return $response;
    }
    
    public function failure_response($msg, $error)
    {
        $response = array(
          "success" => false,
          "msg" => $msg,
          "error" => $error
        );
        return $response;
    }
    public function index_post()
    {
        $stream_clean = $this->security->xss_clean($this->input->raw_input_stream);
        $request = json_decode($stream_clean);
        $username = $request->username;
        $password = $request->password;
        $deviceType = $request->deviceType;
        $deviceToken = $request->deviceToken;
        $timeStamp = $request->timeStamp;
        
        $result = $this->db->select('*')->where(array('email' => $username, 'password' => $password))->get('user')->row_array();
        unset($result['deviceType'], $result['deviceToken'], $result['password']);
        
        
        if(isset($result) && !empty($result)){
            
        $accesToken = $this->token($result);
        $result['authToken'] = $accesToken;
        $result['deviceType'] = $deviceType;
        $result['userId'] = $result['id'];
        $result['deviceToken'] = $deviceToken;
            $msg = "Success";
            $response = $this->success_response($msg, $result);
        } else {
            $msg = "Wrong credentials";
            $response = $this->failure_response($msg, $result);
        }
        $this->response($response, 200);
        
    }

    public function index_otp()
    {
        echo "<pre>";
        print_r('Vikas Saini');
        die;
    }

    // public function storeStudent_post()
    // {
    //     $students = new StudentModel;
    //     $data = [
    //         'name' =>  $this->input->post('name'),
    //         'class' => $this->input->post('class'),
    //         'email' => $this->input->post('email')
    //     ];
    //     $result = $students->insert_student($data);
    //     if($result > 0)
    //     {
    //         $this->response([
    //             'status' => true,
    //             'message' => 'NEW STUDENT CREATED'
    //         ], RestController::HTTP_OK); 
    //     }
    //     else
    //     {
    //         $this->response([
    //             'status' => false,
    //             'message' => 'FAILED TO CREATE NEW STUDENT'
    //         ], RestController::HTTP_BAD_REQUEST);
    //     }
    // }

    public function editStudent_get($id)
    {
        $students = new StudentModel;
        $students = $students->edit_student($id);
        $this->response($students, 200);
    }

    public function updateStudent_put($id)
    {
        $students = new StudentModel;
        $data = [
            'name' =>  $this->put('name'),
            'class' => $this->put('class'),
            'email' => $this->put('email')
        ];
        $result = $students->update_student($id, $data);
        if($result > 0)
        {
            $this->response([
                'status' => true,
                'message' => 'STUDENT UPDATED'
            ], RestController::HTTP_OK); 
        }
        else
        {
            $this->response([
                'status' => false,
                'message' => 'FAILED TO UPDATE STUDENT'
            ], RestController::HTTP_BAD_REQUEST);
        }
    }

    public function deleteStudent_delete($id)
    {
        $students = new StudentModel;
        $result = $students->delete_student($id);
        if($result > 0)
        {
            $this->response([
                'status' => true,
                'message' => 'STUDENT DELETED'
            ], RestController::HTTP_OK); 
        }
        else
        {
            $this->response([
                'status' => false,
                'message' => 'FAILED TO DELETE STUDENT'
            ], RestController::HTTP_BAD_REQUEST);
        }
    }
}

?>