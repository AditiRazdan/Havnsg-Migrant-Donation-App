<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/RestController.php';
require APPPATH . '/libraries/Format.php';

use chriskacerguis\RestServer\RestController;

class RemoveReceive extends RestController
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        // $this->load->model('StudentModel');
    }
    
    public function token($data)
    {
        $jwt = new JWT();
        $jwtSecretKey = "Superman@77";
        $token = $jwt->encode($data, $jwtSecretKey, 'HS256');
        return $token;
    }
    
    public function get_token($dataToken){
        $jwt = new JWT();
        $jwtSecretKey = "Superman@77";
        $token = $jwt->decode($dataToken,$jwtSecretKey,true);
        return $token;
    }
    public function success_response($msg, $data)
    {
        $response = array(
          "success" => true,
          "msg" => $msg,
          "data" => $data
        );
        return $response;
    }
    
    public function failure_response($msg, $error)
    {
        $response = array(
          "success" => false,
          "msg" => $msg,
          "error" => $error
        );
        return $response;
    }

    public function index_get()
    {
        $id = $this->uri->segment(3);
        $Authorization = $this->input->get_request_header("Authorization");
       if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           
            if($accesToken->userType == 'receiver'){
               
                $date = date('Y-m-d H:i:s', time());
                $date = date('Y-m-d H:i:s', time());
                $params = array(
                    "isActive" => 0,
    				'createdAt' => $date,
    				'createdBy' => $accesToken->id,
    				'modifiedAt' => $date,
    				'modifiedBy' => $accesToken->id,
                );
                $this->db->where('id', $id);
                $this->db->update('receive', $params);
                $msg = "Request deleted";
                $response = $this->success_response($msg, '');
            }else{
                $msg = "Only Receiver can remove the Recieve request";
                $response = $this->failure_response($msg, '');
            }  
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        $this->response($response, 200); 
    }

}

?>