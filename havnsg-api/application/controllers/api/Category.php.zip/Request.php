<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
class Request extends CI_Controller {  
	public function __construct(){ 
		parent::__construct();
		$this->load->database();
		//$this->oakter = $this->load->database('oakter',TRUE);
		$this->load->library(array('form_validation')); 
		$this->load->helper(array('url','html','form'));
	}
	
	public function token($data)
    {
        $jwt = new JWT();
        $jwtSecretKey = "Superman@77";
        $token = $jwt->encode($data, $jwtSecretKey, 'HS256');
        return $token;
    }
    
    public function get_token($dataToken){
        $jwt = new JWT();
        $jwtSecretKey = "Superman@77";
        $token = $jwt->decode($dataToken,$jwtSecretKey,true);
        return $token;
    }
	public function success_response($msg, $data)
    {
        $response = array(
          "success" => true,
          "msg" => $msg,
          "data" => $data
        );
        return $response;
    }
    
    public function failure_response($msg, $error)
    {
        $response = array(
          "success" => false,
          "msg" => $msg,
          "error" => $error
        );
        return $response;
    }
	public function matched(){
	    $Authorization = $this->input->get_request_header("Authorization");
		if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           $fromCol = '';
           $res = array();
            if($accesToken->userType == 'doner'){
                $result = $this->db->select('*')->where(array('userId' => $accesToken->id, 'isActive' => 1))->get('donates')->result_array();
                $i=0;
                foreach($result as $r) {
                    $subcategory = $this->db->select('*')->where(array('subcategoryId' => $r->subcategoryId))->get('donates')->row_array();
                    $res[$i] = $result;
                    $res[$i]['matchedRequest'] = $subcategory;
                 $i++;   
                }
            }elseif($accesToken->userType == 'receiver'){
                $result = $this->db->select('*')->where(array('userId' => $accesToken->id, 'isActive' => 1))->get('donates')->result_array();
                $i=0;
                foreach($result as $r) {
                    $receiver = $this->db->select('*')->where(array('subcategoryId' => $r->subcategoryId))->get('receive')->row_array();
                    $res[$i] = $result;
                    $res[$i]['matchedRequest'] = $receiver;  
                }
                
            } 
            $msg = 'Ok';
            $response = $this->success_response($msg, $res);
            
            
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
	}
	
	public function sendRequest(){
	    $Authorization = $this->input->get_request_header("Authorization");
	    if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           
	    $inputData = file_get_contents('php://input');
	    $inputData = json_decode($inputData);
	    $donationId = $inputData->donationId;
	    $receiveId = $inputData->receiveId;
	    
	    $record = $this->db->select('*')->where(array('donationId' => $donationId, 'receiveId' => $receiveId, 'isActive' => 1))->get('requestMapping')->result_array();
	    if (count($record) > 0) {
            $msg = "Already matched";
            $response = $this->failure_response($msg, '');
        }
        $donerRegion = $this->db->select('*')->where(array('id' => $donationId, 'isActive' => 1))->get('donates')->row_array();
        $receiveRegion = $this->db->select('*')->where(array('id' => $receiveId, 'isActive' => 1))->get('receive')->row_array();
        $response = '';
        $date = date('Y-m-d H:i:s', time());
            if($accesToken->userType == 'doner'){
               $params = array(
                    'donationId' => $donationId,
                    'receiveId' => $receiveId,
                    'initiatedBy' => $donerRegion['createdBy'],
                    'region' => $donerRegion['region'],
                    'status' => 'Matched',
                    'createdAt' => $date,
                    'createdBy' => $accesToken->id,
                    'modifiedAt' => $date,
                    'modifiedBy' => $accesToken->id,
                ); 
                $this->db->insert('requestMapping',$params); 
                $requestMappingId = $this->db->insert_id();
                $request = $this->db->select('*')->where('id', $requestMappingId)->get('requestMapping')->row_array();
                $msg = "Request Mapped";
                $response = $this->success_response($msg, $request);
            }
            else if($accesToken->userType == 'receiver'){
               $params = array(
                    'donationId' => $donationId,
                    'receiveId' => $receiveId,
                    'initiatedBy' => $receiveRegion['createdBy'],
                    'region' => $receiveRegion['region'],
                    'status' => 'Matched',
                    'createdAt' => $date,
                    'createdBy' => $accesToken->id,
                    'modifiedAt' => $date,
                    'modifiedBy' => $accesToken->id,
               ); 
                $this->db->insert('requestMapping',$params); 
                $requestMappingId = $this->db->insert_id();
                $request = $this->db->select('*')->where('id', $requestMappingId)->get('requestMapping')->row_array();
                $msg = "Request Mapped";
                $response = $this->success_response($msg, $request);
        }
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
	}
	
	
	public function donationList($num=null, $status=null){
	    $Authorization = $this->input->get_request_header("Authorization");
		if(!empty($Authorization)){
		    
		    $requestStatus = array(
                "pending",
                "completed",
                "matched"
               );
            if(!empty($num)){
                $this->db->select('*');
                $donationRequestData = $this->db->where(array('isActive' => 1, 'userId' => $num))->get('donates')->result_array(); 
                
            }   
            elseif(!empty($status)){
                $status = strtolower($status);
               $indexOfStatus = in_array($status, $requestStatus); 
               if($indexOfStatus < 0){
                   $msg = "Please give suggested status only";
                   $response = $this->failure_response($msg, '');
               }else{
                 $this->db->select('*');
                 $donationRequestData = $this->db->where(array('isActive' => 1, 'userId' => $num, 'status' => $status))->get('donates')->result_array();   
               }
            }else{
               $this->db->select('*');
               $donationRequestData = $this->db->where(array('isActive' => 1))->get('donates')->result_array(); 
            }
            
            
            $result = array();
            $i =0;
            foreach($donationRequestData as $rrd) {
                $categoryData = $this->db->select('*')->where('id', $rrd['categoryId'])->get('categories')->row_array();
                $subCategoryData = $this->db->select('*')->where('id', $rrd['subcategoryId'])->get('categories')->row_array();
                $result[$i]['_id'] = $rrd['id'];
                $result[$i]['userId'] = $rrd['userId'];
                $result[$i]['categoryId'] = $rrd['categoryId'];
                $result[$i]['subcategoryId'] = $rrd['subcategoryId'];
                $result[$i]['description'] = $rrd['description'];
                $result[$i]['region'] = $rrd['region'];
                $result[$i]['deliveryType'] = $rrd['deliveryType'];
                $result[$i]['address'] = $rrd['address'];
                $result[$i]['cretedAt'] = ($rrd['createdAt']?date_format(date_create($rrd['createdAt']),"m/d/Y h:i:s A"):'');
                $result[$i]['createdBy'] = $rrd['createdBy'];
                $result[$i]['modifiedAt'] = $rrd['modifiedAt'];
                $result[$i]['modifiedBy'] = $rrd['modifiedBy'];
                $result[$i]['status'] = $rrd['status'];
                $result[$i]['categoryName'] = $categoryData['name'];
                $result[$i]['subCategoryName'] = $subCategoryData['name']; 
            }
            $msg = "OK";
            $response = $this->success_response($msg, $result);
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
	}
	
		
	public function donationListByStatus($status){
	   // echo "<pre>";
    //         print_r('VIkas');
    //         die;
	    $Authorization = $this->input->get_request_header("Authorization");
		if(!empty($Authorization)){
		    
		    $requestStatus = array(
                "pending",
                "completed",
                "matched"
               );
               
                $status = strtolower($status);
               $indexOfStatus = in_array($status, $requestStatus); 
               if($indexOfStatus < 0){
                   $msg = "Please give suggested status only";
                   $response = $this->failure_response($msg, '');
               }else{
                 $this->db->select('*');
                 $donationRequestData = $this->db->where(array('isActive' => 1, 'status' => $status))->get('donates')->result_array();   
               
            
            $result = array();
            $i =0;
            foreach($donationRequestData as $rrd) {
                $categoryData = $this->db->select('*')->where('id', $rrd['categoryId'])->get('categories')->row_array();
                $subCategoryData = $this->db->select('*')->where('id', $rrd['subcategoryId'])->get('categories')->row_array();
                $result[$i]['_id'] = $rrd['id'];
                $result[$i]['userId'] = $rrd['userId'];
                $result[$i]['categoryId'] = $rrd['categoryId'];
                $result[$i]['subcategoryId'] = $rrd['subcategoryId'];
                $result[$i]['description'] = $rrd['description'];
                $result[$i]['region'] = $rrd['region'];
                $result[$i]['deliveryType'] = $rrd['deliveryType'];
                $result[$i]['address'] = $rrd['address'];
                $result[$i]['cretedAt'] = ($rrd['createdAt']?date_format(date_create($rrd['createdAt']),"m/d/Y h:i:s A"):'');
                $result[$i]['createdBy'] = $rrd['createdBy'];
                $result[$i]['modifiedAt'] = $rrd['modifiedAt'];
                $result[$i]['modifiedBy'] = $rrd['modifiedBy'];
                $result[$i]['status'] = $rrd['status'];
                $result[$i]['categoryName'] = $categoryData['name'];
                $result[$i]['subCategoryName'] = $subCategoryData['name']; 
            }
            $msg = "OK";
            $response = $this->success_response($msg, $result);
               }
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
	}
	
	
	public function donationListByRegion($region){
	   // echo "<pre>";
    //         print_r('VIkas');
    //         die;
	    $Authorization = $this->input->get_request_header("Authorization");
		if(!empty($Authorization)){
           $region = str_replace("%20"," ",$region);
		    
                 $this->db->select('*');
                 $donationRequestData = $this->db->where(array('isActive' => 1, 'region' => $region))->get('donates')->result_array();   
               
            
            $result = array();
            $i =0;
            foreach($donationRequestData as $rrd) {
                $categoryData = $this->db->select('*')->where('id', $rrd['categoryId'])->get('categories')->row_array();
                $subCategoryData = $this->db->select('*')->where('id', $rrd['subcategoryId'])->get('categories')->row_array();
                $result[$i]['_id'] = $rrd['id'];
                $result[$i]['userId'] = $rrd['userId'];
                $result[$i]['categoryId'] = $rrd['categoryId'];
                $result[$i]['subcategoryId'] = $rrd['subcategoryId'];
                $result[$i]['description'] = $rrd['description'];
                $result[$i]['region'] = $rrd['region'];
                $result[$i]['deliveryType'] = $rrd['deliveryType'];
                $result[$i]['address'] = $rrd['address'];
                $result[$i]['cretedAt'] = ($rrd['createdAt']?date_format(date_create($rrd['createdAt']),"m/d/Y h:i:s A"):'');
                $result[$i]['createdBy'] = $rrd['createdBy'];
                $result[$i]['modifiedAt'] = $rrd['modifiedAt'];
                $result[$i]['modifiedBy'] = $rrd['modifiedBy'];
                $result[$i]['status'] = $rrd['status'];
                $result[$i]['categoryName'] = $categoryData['name'];
                $result[$i]['subCategoryName'] = $subCategoryData['name']; 
            }
            $msg = "OK";
            $response = $this->success_response($msg, $result);
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
	}
	
	
	
	public function receiveList($num=null, $status=null){
	    $Authorization = $this->input->get_request_header("Authorization");
		if(!empty($Authorization)){
		    
		    $requestStatus = array(
                "pending",
                "completed",
                "matched"
               );
            if(!empty($num)){
                $this->db->select('*');
                $receiveRequestData = $this->db->where(array('isActive' => 1, 'userId' => $num))->get('receive')->result_array(); 
                
            }   
            elseif(!empty($status)){
                $status = strtolower($status);
               $indexOfStatus = in_array($status, $requestStatus); 
               if($indexOfStatus < 0){
                   $msg = "Please give suggested status only";
                   $response = $this->failure_response($msg, '');
               }else{
                 $this->db->select('*');
                 $receiveRequestData = $this->db->where(array('isActive' => 1, 'userId' => $num, 'status' => $status))->get('receive')->result_array();   
               }
            }else{
               $this->db->select('*');
               $receiveRequestData = $this->db->where(array('isActive' => 1))->get('receive')->result_array(); 
            }
            
            
            $result = array();
            $i =0;
            foreach($receiveRequestData as $rrd) {
                $categoryData = $this->db->select('*')->where('id', $rrd['categoryId'])->get('categories')->row_array();
                $subCategoryData = $this->db->select('*')->where('id', $rrd['subcategoryId'])->get('categories')->row_array();
                $result[$i]['_id'] = $rrd['id'];
                $result[$i]['userId'] = $rrd['userId'];
                $result[$i]['categoryId'] = $rrd['categoryId'];
                $result[$i]['subcategoryId'] = $rrd['subcategoryId'];
                $result[$i]['description'] = $rrd['description'];
                $result[$i]['region'] = $rrd['region'];
                $result[$i]['deliveryType'] = $rrd['deliveryType'];
                $result[$i]['address'] = $rrd['address'];
                $result[$i]['cretedAt'] = ($rrd['createdAt']?date_format(date_create($rrd['createdAt']),"m/d/Y h:i:s A"):'');
                $result[$i]['createdBy'] = $rrd['createdBy'];
                $result[$i]['modifiedAt'] = $rrd['modifiedAt'];
                $result[$i]['modifiedBy'] = $rrd['modifiedBy'];
                $result[$i]['status'] = $rrd['status'];
                $result[$i]['categoryName'] = $categoryData['name'];
                $result[$i]['subCategoryName'] = $subCategoryData['name']; 
            }
            $msg = "OK";
            $response = $this->success_response($msg, $result);
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
	}
	
		
	public function receiveListByStatus($status){
	   // echo "<pre>";
    //         print_r('VIkas');
    //         die;
	    $Authorization = $this->input->get_request_header("Authorization");
		if(!empty($Authorization)){
		    
		    $requestStatus = array(
                "pending",
                "completed",
                "matched"
               );
               
                $status = strtolower($status);
               $indexOfStatus = in_array($status, $requestStatus); 
               if($indexOfStatus < 0){
                   $msg = "Please give suggested status only";
                   $response = $this->failure_response($msg, '');
               }else{
                 $this->db->select('*');
                 $receiveRequestData = $this->db->where(array('isActive' => 1, 'status' => $status))->get('receive')->result_array();   
               
            
            $result = array();
            $i =0;
            foreach($receiveRequestData as $rrd) {
                $categoryData = $this->db->select('*')->where('id', $rrd['categoryId'])->get('categories')->row_array();
                $subCategoryData = $this->db->select('*')->where('id', $rrd['subcategoryId'])->get('categories')->row_array();
                $result[$i]['_id'] = $rrd['id'];
                $result[$i]['userId'] = $rrd['userId'];
                $result[$i]['categoryId'] = $rrd['categoryId'];
                $result[$i]['subcategoryId'] = $rrd['subcategoryId'];
                $result[$i]['description'] = $rrd['description'];
                $result[$i]['region'] = $rrd['region'];
                $result[$i]['deliveryType'] = $rrd['deliveryType'];
                $result[$i]['address'] = $rrd['address'];
                $result[$i]['cretedAt'] = ($rrd['createdAt']?date_format(date_create($rrd['createdAt']),"m/d/Y h:i:s A"):'');
                $result[$i]['createdBy'] = $rrd['createdBy'];
                $result[$i]['modifiedAt'] = $rrd['modifiedAt'];
                $result[$i]['modifiedBy'] = $rrd['modifiedBy'];
                $result[$i]['status'] = $rrd['status'];
                $result[$i]['categoryName'] = $categoryData['name'];
                $result[$i]['subCategoryName'] = $subCategoryData['name']; 
            }
            $msg = "OK";
            $response = $this->success_response($msg, $result);
               }
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
	}
	
	
	public function receiveListByRegion($region){
	   // echo "<pre>";
    //         print_r('VIkas');
    //         die;
	    $Authorization = $this->input->get_request_header("Authorization");
		if(!empty($Authorization)){
           $region = str_replace("%20"," ",$region);
		    
                 $this->db->select('*');
                 $receiveRequestData = $this->db->where(array('isActive' => 1, 'region' => $region))->get('receive')->result_array();   
               
            
            $result = array();
            $i =0;
            foreach($receiveRequestData as $rrd) {
                $categoryData = $this->db->select('*')->where('id', $rrd['categoryId'])->get('categories')->row_array();
                $subCategoryData = $this->db->select('*')->where('id', $rrd['subcategoryId'])->get('categories')->row_array();
                $result[$i]['_id'] = $rrd['id'];
                $result[$i]['userId'] = $rrd['userId'];
                $result[$i]['categoryId'] = $rrd['categoryId'];
                $result[$i]['subcategoryId'] = $rrd['subcategoryId'];
                $result[$i]['description'] = $rrd['description'];
                $result[$i]['region'] = $rrd['region'];
                $result[$i]['deliveryType'] = $rrd['deliveryType'];
                $result[$i]['address'] = $rrd['address'];
                $result[$i]['cretedAt'] = ($rrd['createdAt']?date_format(date_create($rrd['createdAt']),"m/d/Y h:i:s A"):'');
                $result[$i]['createdBy'] = $rrd['createdBy'];
                $result[$i]['modifiedAt'] = $rrd['modifiedAt'];
                $result[$i]['modifiedBy'] = $rrd['modifiedBy'];
                $result[$i]['status'] = $rrd['status'];
                $result[$i]['categoryName'] = $categoryData['name'];
                $result[$i]['subCategoryName'] = $subCategoryData['name']; 
            }
            $msg = "OK";
            $response = $this->success_response($msg, $result);
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
	}

	public function donationDetails($num){
	   // echo "<pre>";
    //         print_r('VIkas');
    //         die;
	    $Authorization = $this->input->get_request_header("Authorization");
		if(!empty($Authorization)){
		    
                 $this->db->select('*');
                 $donationRequestData = $this->db->where(array('isActive' => 1, 'id' => $num))->get('donates')->result_array();   
               
            
            $result = array();
            $i =0;
            foreach($donationRequestData as $rrd) {
                $categoryData = $this->db->select('*')->where('id', $rrd['categoryId'])->get('categories')->row_array();
                $subCategoryData = $this->db->select('*')->where('id', $rrd['subcategoryId'])->get('categories')->row_array();
                $result[$i]['_id'] = $rrd['id'];
                $result[$i]['userId'] = $rrd['userId'];
                $result[$i]['categoryId'] = $rrd['categoryId'];
                $result[$i]['subcategoryId'] = $rrd['subcategoryId'];
                $result[$i]['description'] = $rrd['description'];
                $result[$i]['image'] = $rrd['image'];
                $result[$i]['region'] = $rrd['region'];
                $result[$i]['deliveryType'] = $rrd['deliveryType'];
                $result[$i]['address'] = $rrd['address'];
                $result[$i]['cretedAt'] = ($rrd['createdAt']?date_format(date_create($rrd['createdAt']),"m/d/Y h:i:s A"):'');
                $result[$i]['createdBy'] = $rrd['createdBy'];
                $result[$i]['modifiedAt'] = $rrd['modifiedAt'];
                $result[$i]['modifiedBy'] = $rrd['modifiedBy'];
                $result[$i]['status'] = $rrd['status'];
                $result[$i]['categoryName'] = $categoryData['name'];
                $result[$i]['subCategoryName'] = $subCategoryData['name']; 
            }
            $msg = "OK";
            $response = $this->success_response($msg, $result);
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
	}
	
	public function receiveDetails($num){
	   // echo "<pre>";
    //         print_r('VIkas');
    //         die;
	    $Authorization = $this->input->get_request_header("Authorization");
		if(!empty($Authorization)){
		    
                 $this->db->select('*');
                 $receiveRequestData = $this->db->where(array('isActive' => 1, 'id' => $num))->get('receive')->result_array();   
               
            
            $result = array();
            $i =0;
            foreach($receiveRequestData as $rrd) {
                $categoryData = $this->db->select('*')->where('id', $rrd['categoryId'])->get('categories')->row_array();
                $subCategoryData = $this->db->select('*')->where('id', $rrd['subcategoryId'])->get('categories')->row_array();
                $result[$i]['_id'] = $rrd['id'];
                $result[$i]['userId'] = $rrd['userId'];
                $result[$i]['categoryId'] = $rrd['categoryId'];
                $result[$i]['subcategoryId'] = $rrd['subcategoryId'];
                $result[$i]['description'] = $rrd['description'];
                $result[$i]['region'] = $rrd['region'];
                $result[$i]['deliveryType'] = $rrd['deliveryType'];
                $result[$i]['address'] = $rrd['address'];
                $result[$i]['cretedAt'] = ($rrd['createdAt']?date_format(date_create($rrd['createdAt']),"m/d/Y h:i:s A"):'');
                $result[$i]['createdBy'] = $rrd['createdBy'];
                $result[$i]['modifiedAt'] = $rrd['modifiedAt'];
                $result[$i]['modifiedBy'] = $rrd['modifiedBy'];
                $result[$i]['status'] = $rrd['status'];
                $result[$i]['categoryName'] = $categoryData['name'];
                $result[$i]['subCategoryName'] = $subCategoryData['name']; 
            }
            $msg = "OK";
            $response = $this->success_response($msg, $result);
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
	}
	
	
	
	public function editDonationDetails($num)
    {
       $Authorization = $this->input->get_request_header("Authorization");
       if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           $doner = $this->db->select('*')->where('id', $num)->get('donates')->row_array();
            if($accesToken->userType == 'doner'){
                if(!empty($_FILES["image"]['name']))
                { 
                    $fileName = $this->upload_doc_single('uploads/doner', $_FILES["image"], 'image');
                }else{
                    $fileName = $doner['image'];
                }
                $date = date('Y-m-d H:i:s', time());
                $params = array(
                    "categoryId" => $_POST['categoryId'],
                    "subcategoryId" => $_POST['subcategoryId'],
                    "description" => $_POST['description'],
                    "image" => $fileName,
                    "region" => $_POST['region'],
                    "deliveryType" => $_POST['deliveryType'],
                    "address" => $_POST['address'],
                    "status" => "Pending",
    				'createdAt' => $date,
    				'createdBy' => $accesToken->id,
    				'modifiedAt' => $date,
    				'modifiedBy' => $accesToken->id,
                );
                $this->db->where('id', $num);
                $this->db->update('donates', $params);
                $msg = "Donation detail updated";
                $response = $this->success_response($msg, '');
        //   echo "<pre>";
        //   print_r($params);
        //   die;
            }else{
                $msg = "Only Doner can edit the Donate request";
                $response = $this->failure_response($msg, '');
            }  
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
    }
    
    
	public function editReceiveDetails($num)
    {
       $Authorization = $this->input->get_request_header("Authorization");
       if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           $receive = $this->db->select('*')->where('id', $num)->get('receive')->row_array();
            if($accesToken->userType == 'receiver'){
                $date = date('Y-m-d H:i:s', time());
                $params = array(
                    "categoryId" => $_POST['categoryId'],
                    "subcategoryId" => $_POST['subcategoryId'],
                    "description" => $_POST['description'],
                    "region" => $_POST['region'],
                    "deliveryType" => $_POST['deliveryType'],
                    "address" => $_POST['address'],
                    "status" => "Pending",
    				'createdAt' => $date,
    				'createdBy' => $accesToken->id,
    				'modifiedAt' => $date,
    				'modifiedBy' => $accesToken->id,
                );
                $this->db->where('id', $num);
                $this->db->update('receive', $params);
                $msg = "Receive detail updated";
                $response = $this->success_response($msg, '');
        //   echo "<pre>";
        //   print_r($params);
        //   die;
            }else{
                $msg = "Only Receiver can Edit the Recieve request";
                $response = $this->failure_response($msg, '');
            }  
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
    }
    
     
	public function changeDonationStatus($num)
    {
       $Authorization = $this->input->get_request_header("Authorization");
       if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           $donationId = '';
           $receiveId = '';
           $mappedReq = '';
           $requestStatus = array(
                "pending",
                "completed",
                "matched"
               );
               
            $inputData = file_get_contents('php://input');
            $inputData = json_decode($inputData);
            $status = strtolower($inputData->status);
            $indexOfStatus = in_array($status, $requestStatus);
            if($indexOfStatus != 1){
                $msg = "Please give suggested status only";
                $response = $this->failure_response($msg, '');
            }else{
                $donationId = $num;
                $mappedReq = $this->db->select('*')->where(array('donationId' => $donationId, 'isActive' => 1))->get('requestMapping')->row_array();
                if(!empty($mappedReq)){
                    if($status == "matched"){
                        $msg = "You can not set status as Matched";
                        $response = $this->failure_response($msg, '');
                    }else{
                        $paramRequestMap = array(
                            'status' => $inputData->status,
                            'isActive' => 0
                        );
                        $this->db->where('id', $mappedReq['id']);
                        $this->db->update('requestMapping', $paramRequestMap);
                        $paramDonate = array(
                            'status' => $inputData->status
                        );
                        $this->db->where('id', $donationId);
                        $this->db->update('donates', $paramDonate);
                        $msg = "Donation Status Changed";
                        $response = $this->success_response($msg, '');
                        $notificationDonorData = array();
                        if($status == 'pending'){
                           $notificationDonorData = array(
                               'subject' => "You have rejected Donation Offer",
                               'message' => "Click to view"
                            ); 
                        }
                        
                        if($status == 'completed'){
                           $notificationDonorData = array(
                               'subject' => "You have completed Donation Offer",
                               'message' => "Click to view"
                            ); 
                        }
                        $donorData = $this->getUserByDonationId($donationId);
                        // $this->sendNotificationToSingleUser($notificationDonorData, $donorData);
                        
                    }
                } 
            }
             
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
    }
    
    
	public function changeReceiveStatus($num)
    {
       $Authorization = $this->input->get_request_header("Authorization");
       if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           $donationId = '';
           $receiveId = '';
           $mappedReq = '';
           $requestStatus = array(
                "pending",
                "completed",
                "matched"
               );
               
            $inputData = file_get_contents('php://input');
            $inputData = json_decode($inputData);
            $status = strtolower($inputData->status);
            $indexOfStatus = in_array($status, $requestStatus);
            if($indexOfStatus != 1){
                $msg = "Please give suggested status only";
                $response = $this->failure_response($msg, '');
            }else{
                $receiveId = $num;
                $mappedReq = $this->db->select('*')->where(array('receiveId' => $receiveId, 'isActive' => 1))->get('requestMapping')->row_array();
                if(!empty($mappedReq)){
                    if($status == "matched"){
                        $msg = "You can not set status as Matched";
                        $response = $this->failure_response($msg, '');
                    }else{
                        $paramRequestMap = array(
                            'status' => $inputData->status,
                            'isActive' => 0
                        );
                        $this->db->where('id', $mappedReq['id']);
                        $this->db->update('requestMapping', $paramRequestMap);
                        $paramDonate = array(
                            'status' => $inputData->status
                        );
                        $this->db->where('id', $receiveId);
                        $this->db->update('receive', $paramDonate);
                        $msg = "Donation Status Changed";
                        $response = $this->success_response($msg, '');
                        $notificationDonorData = array();
                        if($status == 'pending'){
                           $notificationDonorData = array(
                               'subject' => "You have rejected Donation Request",
                               'message' => "Click to view"
                            ); 
                        }
                        
                        if($status == 'completed'){
                           $notificationDonorData = array(
                               'subject' => "You have completed Donation Request",
                               'message' => "Click to view"
                            ); 
                        }
                        $donorData = $this->getUserByDonationId($receiveId);
                        // $this->sendNotificationToSingleUser($notificationDonorData, $donorData);
                        
                    }
                } 
            }
             
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
    }
    function getUserByDonationId($donateId){
        $donateUser = $this->db->select('*')->where(array('id' => $donateId))->get('donates')->row_array();
        $user = $this->db->select('*')->where(array('id' => $donateUser['userId']))->get('user')->row_array();
        return $user;
    }
    
    public function matchedRequestByRegion($num){
        $Authorization = $this->input->get_request_header("Authorization");
		if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           $num = str_replace("%20"," ",$num);
            $RequestMap = $this->db->select('*')->where(array('region' => $num, 'isActive' => 1))->get('requestMapping')->result_array();
            $result = array();
            $i =0;
            foreach($RequestMap as $rm){
                $donate = $this->db->select('*')->where(array('id' => $rm['donationId']))->get('donates')->row_array();
                $receives = $this->db->select('*')->where(array('id' => $rm['receiveId']))->get('receive')->row_array();
                $categoryDetails = $this->db->select('*')->where(array('id' => $donate['categoryId']))->get('categories')->row_array();
                $subcategoryDetails = $this->db->select('*')->where(array('id' => $donate['subcategoryId']))->get('categories')->row_array();
                $donerDetails = $this->db->select('*')->where(array('id' => $donate['userId']))->get('user')->row_array();
                $receiverDetails = $this->db->select('*')->where(array('id' => $receives['userId']))->get('user')->row_array();
                
                $result[$i]['_id'] = $rm['id'];
                $result[$i]['donationId'] = $rm['donationId'];
                $result[$i]['receiveId'] = $rm['receiveId'];
                $result[$i]['initiatedBy'] = $rm['initiatedBy'];
                $result[$i]['region'] = $rm['region'];
                $result[$i]['categoryDetails']['_id'] = $categoryDetails['id'];
                $result[$i]['categoryDetails']['name'] = $categoryDetails['name'];
                $result[$i]['subcategoryDetails']['_id'] = $subcategoryDetails['id'];
                $result[$i]['subcategoryDetails']['name'] = $subcategoryDetails['name'];
                $result[$i]['donerDetails']['_id'] = $donerDetails['id'];
                $result[$i]['donerDetails']['firstName'] = $donerDetails['firstName'];
                $result[$i]['donerDetails']['lastName'] = $donerDetails['lastName'];
                $result[$i]['donerDetails']['email'] = $donerDetails['email'];
                $result[$i]['donerDetails']['mobile'] = $donerDetails['mobile'];
                $result[$i]['donerDetails']['region'] = $donerDetails['region'];
                $result[$i]['donerDetails']['address'] = $donerDetails['address'];
                $result[$i]['receiverDetails']['_id'] = $receiverDetails['id'];
                $result[$i]['receiverDetails']['firstName'] = $receiverDetails['firstName'];
                $result[$i]['receiverDetails']['lastName'] = $receiverDetails['lastName'];
                $result[$i]['receiverDetails']['email'] = $receiverDetails['email'];
                $result[$i]['receiverDetails']['mobile'] = $receiverDetails['mobile'];
                $result[$i]['receiverDetails']['region'] = $receiverDetails['region'];
                $result[$i]['receiverDetails']['address'] = $receiverDetails['address'];
                
                $i++;
            }
            $msg = "OK";
            $response = $this->success_response($msg, $result);
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
    }
    
    
    public function matchedRequest(){
        $Authorization = $this->input->get_request_header("Authorization");
		if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
            $RequestMap = $this->db->select('*')->where(array('isActive' => 1))->get('requestMapping')->result_array();
            $result = array();
            $i =0;
            foreach($RequestMap as $rm){
                $donate = $this->db->select('*')->where(array('id' => $rm['donationId']))->get('donates')->row_array();
                $receives = $this->db->select('*')->where(array('id' => $rm['receiveId']))->get('receive')->row_array();
                $categoryDetails = $this->db->select('*')->where(array('id' => $donate['categoryId']))->get('categories')->row_array();
                $subcategoryDetails = $this->db->select('*')->where(array('id' => $donate['subcategoryId']))->get('categories')->row_array();
                $donerDetails = $this->db->select('*')->where(array('id' => $donate['userId']))->get('user')->row_array();
                $receiverDetails = $this->db->select('*')->where(array('id' => $receives['userId']))->get('user')->row_array();
                
                $result[$i]['_id'] = $rm['id'];
                $result[$i]['donationId'] = $rm['donationId'];
                $result[$i]['receiveId'] = $rm['receiveId'];
                $result[$i]['initiatedBy'] = $rm['initiatedBy'];
                $result[$i]['region'] = $rm['region'];
                $result[$i]['categoryDetails']['_id'] = $categoryDetails['id'];
                $result[$i]['categoryDetails']['name'] = $categoryDetails['name'];
                $result[$i]['subcategoryDetails']['_id'] = $subcategoryDetails['id'];
                $result[$i]['subcategoryDetails']['name'] = $subcategoryDetails['name'];
                $result[$i]['donerDetails']['_id'] = $donerDetails['id'];
                $result[$i]['donerDetails']['firstName'] = $donerDetails['firstName'];
                $result[$i]['donerDetails']['lastName'] = $donerDetails['lastName'];
                $result[$i]['donerDetails']['email'] = $donerDetails['email'];
                $result[$i]['donerDetails']['mobile'] = $donerDetails['mobile'];
                $result[$i]['donerDetails']['region'] = $donerDetails['region'];
                $result[$i]['donerDetails']['address'] = $donerDetails['address'];
                $result[$i]['receiverDetails']['_id'] = $receiverDetails['id'];
                $result[$i]['receiverDetails']['firstName'] = $receiverDetails['firstName'];
                $result[$i]['receiverDetails']['lastName'] = $receiverDetails['lastName'];
                $result[$i]['receiverDetails']['email'] = $receiverDetails['email'];
                $result[$i]['receiverDetails']['mobile'] = $receiverDetails['mobile'];
                $result[$i]['receiverDetails']['region'] = $receiverDetails['region'];
                $result[$i]['receiverDetails']['address'] = $receiverDetails['address'];
                
                $i++;
            }
            $msg = "OK";
            $response = $this->success_response($msg, $result);
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
    }
    
      
    public function matchedRequestDetails($num){
        $Authorization = $this->input->get_request_header("Authorization");
		if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
            $RequestMap = $this->db->select('*')->where(array('id' => $num,'isActive' => 1))->get('requestMapping')->result_array();
            $result = array();
            $i =0;
            foreach($RequestMap as $rm){
                $donate = $this->db->select('*')->where(array('id' => $rm['donationId']))->get('donates')->row_array();
                $receives = $this->db->select('*')->where(array('id' => $rm['receiveId']))->get('receive')->row_array();
                $categoryDetails = $this->db->select('*')->where(array('id' => $donate['categoryId']))->get('categories')->row_array();
                $subcategoryDetails = $this->db->select('*')->where(array('id' => $donate['subcategoryId']))->get('categories')->row_array();
                $donerDetails = $this->db->select('*')->where(array('id' => $donate['userId']))->get('user')->row_array();
                $receiverDetails = $this->db->select('*')->where(array('id' => $receives['userId']))->get('user')->row_array();
                
                $result[$i]['_id'] = $rm['id'];
                $result[$i]['donationId'] = $rm['donationId'];
                $result[$i]['receiveId'] = $rm['receiveId'];
                $result[$i]['initiatedBy'] = $rm['initiatedBy'];
                $result[$i]['region'] = $rm['region'];
                $result[$i]['categoryDetails']['_id'] = $categoryDetails['id'];
                $result[$i]['categoryDetails']['name'] = $categoryDetails['name'];
                $result[$i]['subcategoryDetails']['_id'] = $subcategoryDetails['id'];
                $result[$i]['subcategoryDetails']['name'] = $subcategoryDetails['name'];
                $result[$i]['donerDetails']['_id'] = $donerDetails['id'];
                $result[$i]['donerDetails']['firstName'] = $donerDetails['firstName'];
                $result[$i]['donerDetails']['lastName'] = $donerDetails['lastName'];
                $result[$i]['donerDetails']['email'] = $donerDetails['email'];
                $result[$i]['donerDetails']['mobile'] = $donerDetails['mobile'];
                $result[$i]['donerDetails']['region'] = $donerDetails['region'];
                $result[$i]['donerDetails']['address'] = $donerDetails['address'];
                $result[$i]['receiverDetails']['_id'] = $receiverDetails['id'];
                $result[$i]['receiverDetails']['firstName'] = $receiverDetails['firstName'];
                $result[$i]['receiverDetails']['lastName'] = $receiverDetails['lastName'];
                $result[$i]['receiverDetails']['email'] = $receiverDetails['email'];
                $result[$i]['receiverDetails']['mobile'] = $receiverDetails['mobile'];
                $result[$i]['receiverDetails']['region'] = $receiverDetails['region'];
                $result[$i]['receiverDetails']['address'] = $receiverDetails['address'];
                
                $i++;
            }
            $msg = "OK";
            $response = $this->success_response($msg, $result);
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
    }
    
      
    public function matchedRequestDetailsByRequestId($num){
        $Authorization = $this->input->get_request_header("Authorization");
		if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
            $orCon = 'donationId = "'.$num.'" or receiveId = "'.$num.'"';
            $this->db->where('isActive', 1);
            $RequestMap = $this->db->where($orCon)->get('requestMapping')->result_array();
            $result = array();
            $i =0;
            foreach($RequestMap as $rm){
                $donate = $this->db->select('*')->where(array('id' => $rm['donationId']))->get('donates')->row_array();
                $receives = $this->db->select('*')->where(array('id' => $rm['receiveId']))->get('receive')->row_array();
                $categoryDetails = $this->db->select('*')->where(array('id' => $donate['categoryId']))->get('categories')->row_array();
                $subcategoryDetails = $this->db->select('*')->where(array('id' => $donate['subcategoryId']))->get('categories')->row_array();
                $donerDetails = $this->db->select('*')->where(array('id' => $donate['userId']))->get('user')->row_array();
                $receiverDetails = $this->db->select('*')->where(array('id' => $receives['userId']))->get('user')->row_array();
                
                $result[$i]['_id'] = $rm['id'];
                $result[$i]['donationId'] = $rm['donationId'];
                $result[$i]['receiveId'] = $rm['receiveId'];
                $result[$i]['initiatedBy'] = $rm['initiatedBy'];
                $result[$i]['region'] = $rm['region'];
                $result[$i]['categoryDetails']['_id'] = $categoryDetails['id'];
                $result[$i]['categoryDetails']['name'] = $categoryDetails['name'];
                $result[$i]['subcategoryDetails']['_id'] = $subcategoryDetails['id'];
                $result[$i]['subcategoryDetails']['name'] = $subcategoryDetails['name'];
                $result[$i]['donerDetails']['_id'] = $donerDetails['id'];
                $result[$i]['donerDetails']['firstName'] = $donerDetails['firstName'];
                $result[$i]['donerDetails']['lastName'] = $donerDetails['lastName'];
                $result[$i]['donerDetails']['email'] = $donerDetails['email'];
                $result[$i]['donerDetails']['mobile'] = $donerDetails['mobile'];
                $result[$i]['donerDetails']['region'] = $donerDetails['region'];
                $result[$i]['donerDetails']['address'] = $donerDetails['address'];
                $result[$i]['receiverDetails']['_id'] = $receiverDetails['id'];
                $result[$i]['receiverDetails']['firstName'] = $receiverDetails['firstName'];
                $result[$i]['receiverDetails']['lastName'] = $receiverDetails['lastName'];
                $result[$i]['receiverDetails']['email'] = $receiverDetails['email'];
                $result[$i]['receiverDetails']['mobile'] = $receiverDetails['mobile'];
                $result[$i]['receiverDetails']['region'] = $receiverDetails['region'];
                $result[$i]['receiverDetails']['address'] = $receiverDetails['address'];
                
                $i++;
            }
            $msg = "OK";
            $response = $this->success_response($msg, $result);
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
    }
    
    
    public function getRequests(){
        $Authorization = $this->input->get_request_header("Authorization");
		if(!empty($Authorization)){
		    $orCon = 'status = "Pending" or status = "Matched"';
            $this->db->select('*');
            $this->db->where('isActive', 1);
            $receiveRequestData = $this->db->where($orCon)->get('receive')->result_array();
            $result = array();
            $i =0;
            foreach($receiveRequestData as $rrd) {
                $categoryData = $this->db->select('*')->where('id', $rrd['categoryId'])->get('categories')->row_array();
                $subCategoryData = $this->db->select('*')->where('id', $rrd['subcategoryId'])->get('categories')->row_array();
                $result[$i]['_id'] = $rrd['id'];
                $result[$i]['userId'] = $rrd['userId'];
                $result[$i]['categoryId'] = $rrd['categoryId'];
                $result[$i]['subcategoryId'] = $rrd['subcategoryId'];
                $result[$i]['description'] = $rrd['description'];
                $result[$i]['region'] = $rrd['region'];
                $result[$i]['deliveryType'] = $rrd['deliveryType'];
                $result[$i]['address'] = $rrd['address'];
                $result[$i]['cretedAt'] = $rrd['createdAt'];
                $result[$i]['createdBy'] = $rrd['createdBy'];
                $result[$i]['modifiedAt'] = $rrd['modifiedAt'];
                $result[$i]['modifiedBy'] = $rrd['modifiedBy'];
                $result[$i]['status'] = $rrd['status'];
                $result[$i]['categoryName'] = $categoryData['name'];
                $result[$i]['subCategoryName'] = $subCategoryData['name'];
                
                
            }
            $msg = "OK";
            $response = $this->success_response($msg, $result);
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
    }
    
    
    public function getDonates(){
        $Authorization = $this->input->get_request_header("Authorization");
		if(!empty($Authorization)){
		    $orCon = 'status = "Pending" or status = "Matched"';
            $this->db->select('*');
            $this->db->where('isActive', 1);
            $donationRequestData = $this->db->where($orCon)->get('donates')->result_array();
            $result = array();
            $i =0;
            foreach($donationRequestData as $rrd) {
                $categoryData = $this->db->select('*')->where('id', $rrd['categoryId'])->get('categories')->row_array();
                $subCategoryData = $this->db->select('*')->where('id', $rrd['subcategoryId'])->get('categories')->row_array();
                $result[$i]['_id'] = $rrd['id'];
                $result[$i]['userId'] = $rrd['userId'];
                $result[$i]['categoryId'] = $rrd['categoryId'];
                $result[$i]['subcategoryId'] = $rrd['subcategoryId'];
                $result[$i]['description'] = $rrd['description'];
                $result[$i]['image'] = $rrd['image'];
                $result[$i]['region'] = $rrd['region'];
                $result[$i]['deliveryType'] = $rrd['deliveryType'];
                $result[$i]['address'] = $rrd['address'];
                $result[$i]['cretedAt'] = $rrd['createdAt'];
                $result[$i]['createdBy'] = $rrd['createdBy'];
                $result[$i]['modifiedAt'] = $rrd['modifiedAt'];
                $result[$i]['modifiedBy'] = $rrd['modifiedBy'];
                $result[$i]['status'] = $rrd['status'];
                $result[$i]['categoryName'] = $categoryData['name'];
                $result[$i]['subCategoryName'] = $subCategoryData['name']; 
            }
            $msg = "OK";
            $response = $this->success_response($msg, $result);
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
    }
    
    
    
    public function donate($num)
    {
       $Authorization = $this->input->get_request_header("Authorization");
       if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           $this->form_validation->set_rules('categoryId', 'Category', 'required');
           $this->form_validation->set_rules('subcategoryId', 'Sub Category', 'required');
           $this->form_validation->set_rules('description', 'Description', 'required');
           $this->form_validation->set_rules('region', 'Region', 'required');
           $this->form_validation->set_rules('deliveryType', 'Delivery Type', 'required');
           
            if ($this->form_validation->run() == FALSE) {
              print_r($this->form_validation->error_array());
            }else{
                if($accesToken->userType == 'doner'){
                    if(!empty($_FILES["image"]['name']))
                    { 
                        $fileName = $this->upload_doc_single('uploads/doner', $_FILES["image"], 'image');
                    }else{
                        $fileName = "";
                    }
                    
                    $date = date('Y-m-d H:i:s', time());
                    $params = array(
                        "userId" => $accesToken->id,
                        "categoryId" => $_POST['categoryId'],
                        "subcategoryId" => $_POST['subcategoryId'],
                        "description" => $_POST['description'],
                        "image" => $fileName,
                        "region" => $_POST['region'],
                        "deliveryType" => $_POST['deliveryType'],
                        "address" => $_POST['address'],
                        "status" => "Pending",
        				'createdAt' => $date,
        				'createdBy' => $accesToken->id,
        				'modifiedAt' => $date,
        				'modifiedBy' => $accesToken->id,
                    );
                    $this->db->insert('donates',$params); 
                    $donateId = $this->db->insert_id();
                    $donate = $this->db->select('*')->where('id', $donateId)->get('donates')->row_array();
                    $msg = "Request added";
                    $response = $this->success_response($msg, $donate);
                    
                    
            //   echo "<pre>";
            //   print_r($params);
            //   die;
                }else{
                    $msg = "Only Doner can add the Donate request";
                    $response = $this->failure_response($msg, '');
                }     
            }
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
    }
    
    
    public function receive($num)
    {
       $Authorization = $this->input->get_request_header("Authorization");
       if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           $inputData = file_get_contents('php://input');
           $_POST = (array)json_decode($inputData);
           $this->form_validation->set_rules('categoryId', 'Category', 'required');
           $this->form_validation->set_rules('subcategoryId', 'Sub Category', 'required');
           $this->form_validation->set_rules('description', 'Description', 'required');
           $this->form_validation->set_rules('region', 'Region', 'required');
           $this->form_validation->set_rules('deliveryType', 'Delivery Type', 'required');
           
            if ($this->form_validation->run() == FALSE) {
              print_r($this->form_validation->error_array());
            }else{
                if($accesToken->userType == 'receiver'){
                   $date = date('Y-m-d H:i:s', time());
                    $params = array(
                        "userId" => $accesToken->id,
                        "categoryId" => $_POST['categoryId'],
                        "subcategoryId" => $_POST['subcategoryId'],
                        "description" => $_POST['description'],
                        "region" => $_POST['region'],
                        "deliveryType" => $_POST['deliveryType'],
                        "address" => $_POST['address'],
                        "status" => "Pending",
        				'createdAt' => $date,
        				'createdBy' => $accesToken->id,
        				'modifiedAt' => $date,
        				'modifiedBy' => $accesToken->id,
                    );
                    $this->db->insert('receive',$params); 
                    $receiveId = $this->db->insert_id();
                    $receive = $this->db->select('*')->where('id', $receiveId)->get('receive')->row_array();
                    $msg = "Request added";
                    $response = $this->success_response($msg, $receive);
            //   echo "<pre>";
            //   print_r($params);
            //   die;
                }else{
                    $msg = "Only Receiver can add the Recieve request";
                    $response = $this->failure_response($msg, '');
                }     
            }
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
    }
    
    
    public function accept($type, $requestId)
    {
       $Authorization = $this->input->get_request_header("Authorization");
       if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
            if($type == "donation") {
                $receiveRequestData = $this->db->where(array('id' => $requestId))->get('receive')->row_array();
                $date = date('Y-m-d H:i:s', time());
                $params = array(
                    "userId" => $accesToken->id,
                    "categoryId" => $receiveRequestData['categoryId'],
                    "subcategoryId" => $receiveRequestData['subcategoryId'],
                    "description" => $receiveRequestData['description'],
                    "region" => $receiveRequestData['region'],
                    "deliveryType" => $receiveRequestData['deliveryType'],
                    "address" => $receiveRequestData['address'],
                    "status" => "Matched",
    				'createdAt' => $date,
    				'createdBy' => $accesToken->id,
    				'modifiedAt' => $date,
    				'modifiedBy' => $accesToken->id,
                );
                $this->db->insert('donates',$params); 
                $donateId = $this->db->insert_id();
                $donate = $this->db->select('*')->where('id', $donateId)->get('donates')->row_array();
                $msg = "OK";
                $response = $this->success_response($msg, $donate);
                $data = array(
                    'donationId' => $donateId,
                    'receiveId' => $requestId,
                    'initiatedBy' => $accesToken->id,
                    );
                $this->requestMappinMganager($donateId,$requestId,$accesToken->id ,"receive");
                $paramsReceive = array(
                    "status" => "Matched",
                );
                
                $this->db->where('id', $requestId);
                $this->db->update('receive', $paramsReceive);
            }else if($type == "receive") {
                $donateRequestData = $this->db->where(array('id' => $requestId))->get('donates')->row_array();
                $date = date('Y-m-d H:i:s', time());
                $params = array(
                    "userId" => $accesToken->id,
                    "categoryId" => $donateRequestData['categoryId'],
                    "subcategoryId" => $donateRequestData['subcategoryId'],
                    "description" => $donateRequestData['description'],
                    "region" => $donateRequestData['region'],
                    "deliveryType" => $donateRequestData['deliveryType'],
                    "address" => $donateRequestData['address'],
                    "status" => "Matched",
    				'createdAt' => $date,
    				'createdBy' => $accesToken->id,
    				'modifiedAt' => $date,
    				'modifiedBy' => $accesToken->id,
                );
                $this->db->insert('receive',$params); 
                $receiveId = $this->db->insert_id();
                $receive = $this->db->select('*')->where('id', $receiveId)->get('receive')->row_array();
                $msg = "OK";
                $response = $this->success_response($msg, $receive);
                $this->requestMappinMganager($requestId,$receiveId,$accesToken->id ,"donate");
                $paramsReceive = array(
                    "status" => "Matched",
                );
                
                $this->db->where('id', $requestId);
                $this->db->update('receive', $paramsReceive);
            }
                 
           
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        echo json_encode($response);
    }

    
	public function requestMappinMganager($donateId,$requestId,$initiatedBy ,$flag){
	    $donationId = $donateId;
	    $receiveId = $requestId;
	    
	    $record = $this->db->select('*')->where(array('donationId' => $donationId, 'receiveId' => $receiveId, 'isActive' => 1))->get('requestMapping')->result_array();
	    if (count($record) > 0) {
            $msg = "Already matched";
            $response = $this->failure_response($msg, '');
        }
        $donerRegion = $this->db->select('*')->where(array('id' => $donationId, 'isActive' => 1))->get('donates')->row_array();
        $receiveRegion = $this->db->select('*')->where(array('id' => $receiveId, 'isActive' => 1))->get('receive')->row_array();
        $response = '';
        $date = date('Y-m-d H:i:s', time());
            if($flag == 'doner'){
               $params = array(
                    'donationId' => $donationId,
                    'receiveId' => $receiveId,
                    'initiatedBy' => $donerRegion['createdBy'],
                    'region' => $donerRegion['region'],
                    'status' => 'Matched',
                    'createdAt' => $date,
                    'createdBy' => $initiatedBy,
                    'modifiedAt' => $date,
                    'modifiedBy' => $initiatedBy,
                ); 
                $this->db->insert('requestMapping',$params); 
                $requestMappingId = $this->db->insert_id();
                $request = $this->db->select('*')->where('id', $requestMappingId)->get('requestMapping')->row_array();
                $msg = "Request Mapped";
                $response = $this->success_response($msg, $request);
            }
            else if($flag == 'receive'){
               $params = array(
                    'donationId' => $donationId,
                    'receiveId' => $receiveId,
                    'initiatedBy' => $receiveRegion['createdBy'],
                    'region' => $receiveRegion['region'],
                    'status' => 'Matched',
                    'createdAt' => $date,
                    'createdBy' => $initiatedBy,
                    'modifiedAt' => $date,
                    'modifiedBy' => $initiatedBy,
               ); 
                $this->db->insert('requestMapping',$params); 
                $requestMappingId = $this->db->insert_id();
                $request = $this->db->select('*')->where('id', $requestMappingId)->get('requestMapping')->row_array();
                $msg = "Request Mapped";
                $response = $this->success_response($msg, $request);
        }
       
        echo json_encode($response);
	}
}