<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/RestController.php';
require APPPATH . '/libraries/Format.php';

use chriskacerguis\RestServer\RestController;

class Matched extends RestController
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        // $this->load->model('StudentModel');
    }
    
    public function token($data)
    {
        $jwt = new JWT();
        $jwtSecretKey = "Superman@77";
        $token = $jwt->encode($data, $jwtSecretKey, 'HS256');
        return $token;
    }
    
    public function get_token($dataToken){
        $jwt = new JWT();
        $jwtSecretKey = "Superman@77";
        $token = $jwt->decode($dataToken,$jwtSecretKey,true);
        return $token;
    }
    public function success_response($msg, $data)
    {
        $response = array(
          "success" => true,
          "msg" => $msg,
          "data" => $data
        );
        return $response;
    }
    
    public function failure_response($msg, $error)
    {
        $response = array(
          "success" => false,
          "msg" => $msg,
          "error" => $error
        );
        return $response;
    }

    public function index_get()
    {
        $id = $this->uri->segment(3);
        $Authorization = $this->input->get_request_header("Authorization");
       if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           $fromCol = '';
            if($accesToken->userType == 'doner'){
                $fromCol = 'doner';
            }elseif($accesToken->userType == 'receiver'){
                $fromCol = 'receives';
            }    
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        $this->response($response, 200); 
    }

}

?>