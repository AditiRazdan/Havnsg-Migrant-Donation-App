<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/RestController.php';
require APPPATH . '/libraries/Format.php';

use chriskacerguis\RestServer\RestController;

class Subcategory extends RestController
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        // $this->load->model('StudentModel');
    }
    
    public function token($data)
    {
        $jwt = new JWT();
        $jwtSecretKey = "Superman@77";
        $token = $jwt->encode($data, $jwtSecretKey, 'HS256');
        return $token;
    }
    
    public function get_token($dataToken){
        $jwt = new JWT();
        $jwtSecretKey = "Superman@77";
        $token = $jwt->decode($dataToken,$jwtSecretKey,true);
        return $token;
    }
    public function success_response($msg, $data)
    {
        $response = array(
          "success" => true,
          "msg" => $msg,
          "data" => $data
        );
        return $response;
    }
    
    public function failure_response($msg, $error)
    {
        $response = array(
          "success" => false,
          "msg" => $msg,
          "error" => $error
        );
        return $response;
    }
    
    
    public function index_post()
    {
       $Authorization = $this->input->get_request_header("Authorization");
       if(!empty($Authorization)){
           $accesToken = $this->get_token($Authorization);
           $this->form_validation->set_rules('name', 'Name', 'required');
           $this->form_validation->set_rules('parentCategory', 'Category', 'required');
           if(empty($_FILES["categoryImage"]['name']))
            { 
                $this->form_validation->set_rules('categoryImage', 'Category Image', 'required');
            }
            
            if ($this->form_validation->run() == FALSE) {
              print_r($this->form_validation->error_array());
            }else{
                if(!empty($_FILES["categoryImage"]['name']))
                { 
                    $fileName = $this->upload_doc_single('uploads/category', $_FILES["categoryImage"], 'image');
                }else{
                    $fileName = "";
                }
                
                $date = date('Y-m-d H:i:s', time());
                $params = array(
                    "name" => $_POST['name'],
                    "parentCategory" => $_POST['parentCategory'],
                    "categoryImage" => $fileName,
    				'cretedAt' => $date,
    				'createdBy' => $accesToken->id,
    				'modifiedAt' => $date,
    				'modifiedBy' => $accesToken->id,
                );
                $this->db->insert('categories',$params); 
                $categoryId = $this->db->insert_id();
                $category = $this->db->select('*')->where('id', $categoryId)->get('categories')->row_array();
                $msg = "Sub Category Created";
                $response = $this->success_response($msg, $category);
          
                   
            }
       }else{
           $msg = "JWT error";
            $response = $this->failure_response($msg, '');
       }
        $this->response($response, 200); 
    }

        
    public function index_get($num)
    {
        $categoryId = $this->uri->segment(3);
          
        $result = $this->db->select('*')->where('parentCategory', $categoryId)->get('categories')->result_array();
        
        if(isset($result) && !empty($result)){
            $msg = "Success";
            $response = $this->success_response($msg, $result);
        } else {
            $msg = "Category Not Found";
            $response = $this->failure_response($msg, $result);
        }
        $this->response($response, 200);
    }

    
    
        function upload_doc_single($dirname, $file = null, $fileTypeName= null){
        
            $parentdirname = $dirname;
            
            
            $year = date("Y");   
            $month = date("m"); 
            $date = date("d"); 
            $yeardir = $parentdirname.'/'.$year;   
            $monthdir = $yeardir."/".$month;
            $datedir = $monthdir.'/'.$date;
            
            // File management system
            if(file_exists($yeardir)){
                if(file_exists($monthdir)){
                    if(file_exists($datedir)==false){
                        mkdir($datedir,0777);
                    }
                }else{
                    mkdir($monthdir,0777);
                    if(file_exists($datedir)==false){
                        mkdir($datedir,0777);
                    }
                }
            }else{
                mkdir($yeardir,0777);
                if(file_exists($monthdir)){
                    if(file_exists($datedir)==false){
                        mkdir($datedir,0777);
                    }
                }else{
                    mkdir($monthdir,0777);
                    if(file_exists($datedir)==false){
                        mkdir($datedir,0777);
                    }
                }
            }
            
            $filedirname = $datedir;
            

            if(basename($file["name"])){
    		    $docname = $filedirname ."/" . basename($file["name"]);
    		    $doctFileType = pathinfo($docname, PATHINFO_EXTENSION);
    		    $docname = $filedirname ."/" . $fileTypeName. time() . "." . $doctFileType;
    		}else{
    		    $docname = "";
    		}
    		
            $uploadOk = 1;
    		if ($docname == $filedirname."/") {
                $msg = "All documents are empty";
                $uploadOk = 0;
            } // Check if file already exists
            else if (file_exists($docname)) {
                $msg = "Sorry, one or more of these files already exists.";
                $uploadOk = 0;
            } // Check file size
            else if ($file["size"] > 5000000) {
                $msg = "Sorry, one or more of the files is too large.";
                $uploadOk = 0;
            } // Check if $uploadOk is set to 0 by an error
            else if ($uploadOk == 0) {
                $msg = "Sorry, your file was not uploaded.";
        
                // if everything is ok, try to upload file
            } else {
                   
                $msg = "The file ";
                if (move_uploaded_file($file["tmp_name"], $docname)){
                    $msg .=  basename($file["name"]);
                } 
                    $msg .= " have been uploaded.";
                
            }
    		
    		
    		return $docname;
    }

}

?>